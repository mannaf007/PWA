Please see the [contributing](https://github.com/GoogleChromeLabs/pwa-wp/wiki/Contributing) page on the wiki.
